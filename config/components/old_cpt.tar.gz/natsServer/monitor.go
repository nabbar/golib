package request

import (
	"context"

	libmon "github.com/nabbar/golib/monitor"
	monpol "github.com/nabbar/golib/monitor/pool"
	libreq "github.com/nabbar/golib/request"
	libver "github.com/nabbar/golib/version"
)

func (o *componentRequest) RegisterMonitorPool(fct monpol.FuncPool) {
	o.m.Lock()
	defer o.m.Unlock()

	o.p = fct
}

func (o *componentRequest) _getMonitorPool() monpol.Pool {
	o.m.RLock()
	defer o.m.RUnlock()

	if o.p == nil {
		return nil
	} else if p := o.p(); p == nil {
		return nil
	} else {
		return p
	}
}

func (o *componentRequest) _registerMonitor(cfg *libreq.Options) error {
	var (
		e   error
		key = o._getKey()
		mon libmon.Monitor
		vrs = o._getVersion()
		ctx = o._getContext()
	)

	if o._getMonitorPool() == nil {
		return nil
	} else if len(key) < 1 {
		return ErrorComponentNotInitialized.Error(nil)
	} else if cfg == nil {
		return ErrorConfigInvalid.Error(nil)
	} else if !o.IsStarted() {
		return ErrorComponentStart.Error(nil)
	} else if ctx == nil {
		ctx = context.Background()
	}

	if mon = o._getMonitor(key); mon == nil {
		if mon, e = o._newMonitor(ctx, vrs); e != nil {
			return e
		} else if mon == nil {
			return nil
		}
	}

	if e = mon.SetConfig(o.x.GetContext(), cfg.Health.Monitor); e != nil {
		return e
	}

	if mon.IsRunning() {
		if e = mon.Restart(o.x.GetContext()); e != nil {
			return e
		}
	} else if e = mon.Start(o.x.GetContext()); e != nil {
		return e
	}

	o._setMonitor(mon)
	return nil
}

func (o *componentRequest) _newMonitor(ctx context.Context, vrs libver.Version) (libmon.Monitor, error) {
	o.m.RLock()
	defer o.m.RUnlock()
	return o.r.Monitor(ctx, vrs)
}

func (o *componentRequest) _getMonitor(key string) libmon.Monitor {
	var (
		mon libmon.Monitor
		pol = o._getMonitorPool()
	)

	if pol == nil {
		return nil
	}

	mon = pol.MonitorGet(key)
	return mon
}

func (o *componentRequest) _setMonitor(mon libmon.Monitor) {
	var pol = o._getMonitorPool()

	if pol == nil {
		return
	}

	pol.MonitorSet(mon)
}
