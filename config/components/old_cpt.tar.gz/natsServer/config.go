package request

import (
	liberr "github.com/nabbar/golib/errors"
	libreq "github.com/nabbar/golib/request"
	spfcbr "github.com/spf13/cobra"
	spfvpr "github.com/spf13/viper"
)

func (o *componentRequest) RegisterFlag(Command *spfcbr.Command) error {
	return nil
}

func (o *componentRequest) _getConfig() (*libreq.Options, liberr.Error) {
	var (
		key string
		cfg libreq.Options
		vpr *spfvpr.Viper
		err liberr.Error
	)

	if vpr = o._getSPFViper(); vpr == nil {
		return nil, ErrorComponentNotInitialized.Error(nil)
	} else if key = o._getKey(); len(key) < 1 {
		return nil, ErrorComponentNotInitialized.Error(nil)
	}

	if e := vpr.UnmarshalKey(key, &cfg); e != nil {
		return nil, ErrorParamInvalid.ErrorParent(e)
	}

	if err = cfg.Validate(); err != nil {
		return nil, ErrorConfigInvalid.Error(err)
	}

	return &cfg, nil
}
