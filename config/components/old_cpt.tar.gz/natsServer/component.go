package request

import (
	cpttls "github.com/nabbar/golib/config/components/tls"
	cfgtps "github.com/nabbar/golib/config/type"
	libctx "github.com/nabbar/golib/context"
	liberr "github.com/nabbar/golib/errors"
	libver "github.com/nabbar/golib/version"
	libvpr "github.com/nabbar/golib/viper"
)

const (
	ComponentType = "request"

	keyCptKey = iota + 1
	keyFctViper
	keyFctGetCpt
	keyCptVersion
	keyFctStaBef
	keyFctStaAft
	keyFctRelBef
	keyFctRelAft
	keyFctMonitorPool
)

func (o *componentRequest) Type() string {
	return ComponentType
}

func (o *componentRequest) Init(key string, ctx libctx.FuncContext, get cfgtps.FuncCptGet, vpr libvpr.FuncSPFViper, vrs libver.Version) {
	o.m.Lock()
	defer o.m.Unlock()

	o.x = libctx.NewConfig[uint8](ctx)
	o.x.Store(keyCptKey, key)
	o.x.Store(keyFctGetCpt, get)
	o.x.Store(keyFctViper, vpr)
	o.x.Store(keyCptVersion, vrs)
}

func (o *componentRequest) RegisterFuncStart(before, after cfgtps.FuncCptEvent) {
	o.x.Store(keyFctStaBef, before)
	o.x.Store(keyFctStaAft, after)
}

func (o *componentRequest) RegisterFuncReload(before, after cfgtps.FuncCptEvent) {
	o.x.Store(keyFctRelBef, before)
	o.x.Store(keyFctRelAft, after)
}

func (o *componentRequest) IsStarted() bool {
	o.m.RLock()
	defer o.m.RUnlock()

	return o != nil && o.r != nil
}

func (o *componentRequest) IsRunning() bool {
	return o.IsStarted()
}

func (o *componentRequest) Start() liberr.Error {
	return o._run()
}

func (o *componentRequest) Reload() liberr.Error {
	return o._run()
}

func (o *componentRequest) Stop() {
	o.m.Lock()
	defer o.m.Unlock()

	o.r = nil
	return
}

func (o *componentRequest) Dependencies() []string {
	o.m.Lock()
	defer o.m.Unlock()

	if o == nil || o.t == "" {
		return []string{cpttls.ComponentType}
	}

	return []string{o.t}
}
