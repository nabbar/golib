/*
 *  MIT License
 *
 *  Copyright (c) 2020 Nicolas JUHEL
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 *
 */

package jfrog

import (
	"context"

	"github.com/nabbar/golib/ioutils"

	"github.com/jfrog/jfrog-client-go/artifactory/services"

	"github.com/jfrog/jfrog-client-go/artifactory"

	"github.com/hashicorp/go-version"
	"github.com/nabbar/golib/artifact/client"
	"github.com/nabbar/golib/errors"
)

const (
	gitlabPageSize = 100
)

type artifactoryModel struct {
	client.ClientHelper

	c *artifactory.ArtifactoryServicesManager
	o Options
	x context.Context
	r string
}

func (g *artifactoryModel) ListReleases() (releases version.Collection, err errors.Error) {
	/*
		params := services.NewSearchParams()
		params.Pattern = ...
		// Filter the files by properties.
		params.Props = "key1=val1;key2=val2"
		params.Recursive = true

		reader, err := rtManager.SearchFiles(params)
		if err != nil {
			return err
		}
		defer reader.Close()
	*/
	search := services.NewSearchParams()

	if g.o.GetRecursive() {
		search.Recursive = true
	} else {
		search.Recursive = false
	}

	if g.o.GetPattern() != "" {
		search.Pattern = g.o.GetPattern()
	}

	if g.o.GetExcludePattern() != "" {
		search.Exclusions = []string{g.o.GetExcludePattern()}
	}

	if g.o.LenProps() > 0 {
		search.Props = g.o.EncProps()
	}

	if g.o.LenExcludeProps() > 0 {
		search.ExcludeProps = g.o.EncExcludeProps()
	}

	if rCnt, e := g.c.SearchFiles(search); e != nil {
		return nil, ErrorArtifactoryList.ErrorParent(e)
	} else if rCnt == nil {
		panic("not Implemented")
		//@todo: create version files
	}

	panic("not Implemented")
}

func (g *artifactoryModel) GetArtifact(containName string, regexName string, release *version.Version) (link string, err errors.Error) {
	panic("not Implemented")
}

func (g *artifactoryModel) Download(dst ioutils.FileProgress, containName string, regexName string, release *version.Version) errors.Error {
	panic("implement me")
}
